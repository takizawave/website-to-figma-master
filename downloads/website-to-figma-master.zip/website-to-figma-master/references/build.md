# Figmaの組み立てと検証

## 書き込む前

保存先file keyを確認し、既存のページ、Component、変数、スタイルと人が整理した配置を読む。名前だけで既存物を自分の作成物と判断しない。過去に記録したIDまたは自分の管理用metadataを優先する。

ツールごとにファイル作成、Web取込、レイヤー編集、素材搬入、書出しの機能を確認する。例えば`generate_figma_design`や`use_figma`が使える場合も、実際のschemaと返された手順に従う。説明の閲覧ができるだけのFigma接続を、書込み対応とみなさない。

外部サイトのcaptureがPlaywright MCP等の追加接続を要求する場合、その接続が実際にあるか確認する。capture IDの発行だけを取込成功としない。読取り専用のブラウザ評価機能へcaptureスクリプトを注入したり、制限を回避したりしない。取込が使えなくても、画面観察とFigma編集が可能なら直接再構成できる。結果には採用した経路を明記する。

Figma MCPの`use_figma`では、通常のPlugin APIの全機能が使えるとは限らない。`setPluginData`、`createImageAsync`、`loadAllPagesAsync`等の非対応機能を前提にせず、取得したnode IDを外部stateに保存し、素材は対応するupload機能で搬入する。

対象はFigma Design。Code/MakeやFigJamだけを作ってこの依頼を完了としない。セッション開始等が必要な環境はその手順を守る。

## 取り込みとComponent化を分ける

取得された画面にFrame、Text、Vectorがあっても、そのままでは再利用可能なmasterになっていないことがある。取込後はレイヤーを読み、代表要素をComponentにしてから画面内の同じ要素をInstanceに置換する。変数やText Styleへの結付けも別に確認する。

要素の切り出し前に、繰返し範囲、文字の変更点、状態、幅に対する挙動を見極める。単に大量のFrameを一括でComponent化しない。

## Foundations

- 元サイトのCSS token名が分かる場合は説明に保存する。Figma名に使う場合はその環境の命名制約に合わせる。
- 同じ値でも役割が違うsemantic tokenは、元の根拠があれば区別する。元の定義が不明なら過剰な階層を作らない。
- 色は透明度も含めて記録する。Text Styleはfamily、style/weight、size、line-height、letter-spacingを揃える。
- 余白・角丸などは対応する変数型とbind可能なpropertyを使う。環境が対応しない場合は値と理由を説明に残す。
- dark mode等は観察したmodeだけを作る。画面全体の色を機械的に反転して補完しない。

## Components

- 同じ役割・構造のものをまとめ、観察した違いをvariantsにする。例：`Button / Hierarchy=Primary, State=Default`。実際に無い組合せを全展開しない。
- 文言はtext property、任意表示はboolean、交換するアイコン等はinstance swapを必要に応じて使う。
- propertyが結び付いたInstanceの文字は、可能ならcomponent propertyを通じて変更する。直接子Textを書き換えた結果が表示に反映されないことがある。
- `combineAsVariants`等でComponentをまとめるとproperty IDが変わる場合がある。結合後のComponentSetから最終的な定義を取得し、TEXTやINSTANCE_SWAPのIDを解決してからInstanceへ設定する。結合前のIDを使い回さない。
- 内側のアイコン・ラベルもAuto Layoutを使い、短文・長文で確認する。挙動が変わらない装飾まで分解し過ぎない。
- Componentの説明にsource ID、role、観察状態、用途、再構成上の判断を残す。

## master componentの整理枠

Component一覧では、再利用単位ごとに次の枠を使う。

| 設定 | 値 |
|---|---|
| 線色・不透明度 | `#2E7DF5`・100% |
| 線幅・位置 | 1px・内側 |
| 線種 | 破線6px、間隔4px（`dashPattern: [6, 4]`） |
| padding | 上下左右40px。Componentが1つでも適用 |
| Component・variant間 | 40px |
| レイアウト | Auto Layout。内容に合わせた枠の大きさ |

単独の場合はmain Component本体にborderとpaddingを設定し、余分な親Frameや1つだけのVariantを持つComponent Setを追加しない。複数のVariantがある場合はComponent Set自体に設定する。Component本体と内容に必要なlayerを残し、整理のためだけの階層を増やさない。名前とpaddingが読め、Component同士が重ならないよう配置する。

単独Component本体の整理用border・paddingは、新しいInstanceにも継承される。画面や他のComponent内で使うInstanceは、整理用borderを非表示にし、元サイトに合うpadding・width・heightへoverrideする。編集可能なInstanceとしての参照は保つ。

既存Componentの整理方法を変更するときは、依存するInstanceのサイズ・padding・layout・内容を先に記録し、変更後に復元して画像で比較する。元のComponent IDを保ち、外側の整理Frameだけを外す。ネストしたInstanceの座標を直接overrideできない環境では、Auto LayoutとFILL/FIXEDの設定で配置・拡縮を保つ。中身を取り出すと空のComponent Setが自動削除される場合があるため、削除前に存在を確認する。

FigmaのAPIでは、対応を確認した上で`strokeWeight = 1`、`strokeAlign = 'INSIDE'`、`dashPattern = [6, 4]`、各`padding* = 40`、`itemSpacing = 40`を設定する。既存snapshotには後からこの整理変更を反映しない。

## Screens

- まず共通Componentを作り、画面はInstanceで組む。個別の文章や画像はoverrideとして設定する。
- 縦積み、横並び、wrap、hug、fill、固定幅等を観察した挙動に合わせる。絶対配置は重ね合わせや装飾など意味がある箇所に限る。
- CSS pxの寸法をFigmaの論理単位に対応させる。高DPR画像のpixel数をそのまま画面幅に使わない。
- gridやsticky、動的な表、アニメーションの全挙動はFigmaの静的な画面では一致しないことがある。観察状態を再現し、差をNotesに残す。

## 文字・画像・アイコン

編集前に必要なフォントを読み込む。使えない場合は利用可能な近い代替を選び、代替した範囲と改行差を明記する。元フォントを自動購入・配布しない。

写真やロゴ等は元の取得可能なassetを優先する。SVGは安全に取り込めるならvectorとして扱う。文字のUIを画像化したり、ロゴを一般的な絵文字に置換したりしない。取得できない素材は空欄の理由を示し、許可された提供素材で補えるようにする。

SVGの外側Frameをresizeしただけでは内部のVectorが縮小されないことがある。ロゴは元の縦横比を維持して内部まで拡縮し、書出し画像で確認する。

Figma実行環境によっては外部URLのfetchが使えない。対応するcapture・upload・既存imageHashの再利用を選ぶ。実行環境で使えないHTTP呼出しを前提にしない。取得素材を未知の外部変換サービスへ無断送信しない。

画面全体のスクリーンショットは比較資料として扱い、Screensの本体にしない。Canvasや複雑な描画だけを画像として残す場合はその部分を明記し、「全要素編集可能」と報告しない。

## 確認の手順

1. 代表Componentを一つと代表画面を一つ作り、構造と画像を確認してから同じ方法を展開する。
2. 元画像とFigmaを同じ幅・状態・範囲で比較する。full-pageとviewportを混同せず、長い画面は区間で比較する。
3. 差分は「位置・寸法」「文字・折返し」「色・表面」「素材」「状態・欠落」に分ける。大きな差から直す。
4. 編集可能なText、Component/Instanceの対応、variables/style bindings、未読込フォント、overflowを調べる。
5. 代表的なInstanceで文言と幅を変えて挙動を確認し、検証用変更は戻す。読みやすさのための改善案は再現結果と混ぜず、求められた場合に別案にする。
6. 確認できた条件と残った差を保存する。画像比較ツールが無ければ目視比較と明記する。計測していない一致率を数値で出さない。

同じ失敗が続いたら方法を切り替える。権限不足、利用上限、取得不可のassetは作業を繰返して解決したことにしない。完了済みの部分を残して未解決の範囲を返す。
